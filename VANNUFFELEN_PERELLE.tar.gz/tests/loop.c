#include <stdio.h>
void main() {

    while(1){
        printf("Loopin\n");
        sleep(10);
        printf("Still \n");
    }
}