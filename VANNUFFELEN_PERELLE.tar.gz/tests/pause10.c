#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main()
{
    printf("Debut\n");
    sleep(10);
    printf("Fin\n");
    return 0;
}
